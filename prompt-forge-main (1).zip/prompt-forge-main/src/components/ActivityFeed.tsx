import { motion } from "framer-motion";
import { Activity, CheckCircle2, AlertTriangle, Info, XCircle } from "lucide-react";
import { usePrivacy } from "@/context/PrivacyContext";

const typeConfig = {
  info: { icon: Info, color: "text-primary", bg: "bg-primary/10" },
  warning: { icon: AlertTriangle, color: "text-warning", bg: "bg-warning/10" },
  success: { icon: CheckCircle2, color: "text-success", bg: "bg-success/10" },
  error: { icon: XCircle, color: "text-destructive", bg: "bg-destructive/10" },
};

export function ActivityFeed() {
  const { recentActivity } = usePrivacy();

  const formatTime = (ts: string) => {
    const diff = Date.now() - new Date(ts).getTime();
    const mins = Math.floor(diff / 60000);
    if (mins < 60) return `${mins}m ago`;
    const hrs = Math.floor(mins / 60);
    if (hrs < 24) return `${hrs}h ago`;
    return `${Math.floor(hrs / 24)}d ago`;
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.4 }}
      className="glass rounded-2xl overflow-hidden"
    >
      <div className="p-4 border-b border-border flex items-center gap-2">
        <Activity className="w-4 h-4 text-primary" />
        <h3 className="text-sm font-semibold text-foreground">Recent Activity</h3>
      </div>
      <div className="max-h-[400px] overflow-y-auto">
        {recentActivity.map((item, i) => {
          const cfg = typeConfig[item.type];
          const Icon = cfg.icon;
          return (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, x: -8 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.4 + i * 0.05 }}
              className="p-3 border-b border-border/30 hover:bg-muted/20 transition-colors group"
            >
              <div className="flex items-start gap-3">
                <div className={`w-8 h-8 rounded-lg ${cfg.bg} flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform`}>
                  <Icon className={`w-4 h-4 ${cfg.color}`} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-foreground">{item.action}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="text-[11px] text-muted-foreground">{item.user}</span>
                    <span className="text-muted-foreground/30">•</span>
                    <span className="text-[11px] text-muted-foreground">{item.resource}</span>
                  </div>
                </div>
                <span className="text-[10px] text-muted-foreground/60 font-mono shrink-0">{formatTime(item.timestamp)}</span>
              </div>
            </motion.div>
          );
        })}
      </div>
    </motion.div>
  );
}
