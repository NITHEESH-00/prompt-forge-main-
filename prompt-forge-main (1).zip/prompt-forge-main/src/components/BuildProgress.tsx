import { motion } from "framer-motion";

interface BuildProgressProps {
  completed: number;
  total: number;
  label?: string;
}

export function BuildProgress({ completed, total, label }: BuildProgressProps) {
  const pct = total > 0 ? Math.round((completed / total) * 100) : 0;

  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -10 }}
      className="px-4 py-3 glass-strong border-b border-border"
    >
      <div className="flex items-center justify-between mb-2">
        <span className="text-[11px] font-mono text-muted-foreground">
          {label || "Building modules..."}
        </span>
        <span className="text-[11px] font-mono text-primary">
          {completed}/{total} · {pct}%
        </span>
      </div>
      <div className="h-1.5 bg-muted rounded-full overflow-hidden">
        <motion.div
          className="h-full bg-primary rounded-full animate-glow-bar"
          initial={{ width: 0 }}
          animate={{ width: `${pct}%` }}
          transition={{ duration: 0.4, ease: "easeOut" }}
        />
      </div>
    </motion.div>
  );
}
