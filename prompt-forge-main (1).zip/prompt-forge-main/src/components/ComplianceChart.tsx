import { motion } from "framer-motion";
import { TrendingUp, TrendingDown, Minus, BarChart3 } from "lucide-react";
import { usePrivacy } from "@/context/PrivacyContext";

const trendIcons = { up: TrendingUp, down: TrendingDown, stable: Minus };
const trendColors = { up: "text-success", down: "text-destructive", stable: "text-muted-foreground" };
const barColors = ["bg-primary", "bg-accent", "bg-forge-amber", "bg-success"];

export function ComplianceChart() {
  const { complianceMetrics } = usePrivacy();

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.35 }}
      className="glass rounded-2xl overflow-hidden"
    >
      <div className="p-4 border-b border-border flex items-center gap-2">
        <BarChart3 className="w-4 h-4 text-primary" />
        <h3 className="text-sm font-semibold text-foreground">Compliance Overview</h3>
      </div>
      <div className="p-4 space-y-4">
        {complianceMetrics.map((m, i) => {
          const TIcon = trendIcons[m.trend];
          return (
            <div key={m.label} className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-foreground">{m.label}</span>
                <div className="flex items-center gap-2">
                  <span className="text-sm font-bold font-mono text-foreground">{m.score}%</span>
                  <div className={`flex items-center gap-0.5 text-xs ${trendColors[m.trend]}`}>
                    <TIcon className="w-3 h-3" />
                    {m.change !== 0 && <span>{m.change > 0 ? `+${m.change}` : m.change}%</span>}
                  </div>
                </div>
              </div>
              <div className="h-2 bg-muted rounded-full overflow-hidden">
                <motion.div
                  className={`h-full rounded-full ${barColors[i % barColors.length]}`}
                  initial={{ width: 0 }}
                  animate={{ width: `${m.score}%` }}
                  transition={{ duration: 1, delay: 0.5 + i * 0.15, ease: "easeOut" }}
                />
              </div>
            </div>
          );
        })}
      </div>
    </motion.div>
  );
}
