import { motion } from "framer-motion";
import { Database, Shield, AlertCircle, Eye } from "lucide-react";
import { usePrivacy } from "@/context/PrivacyContext";

const classColors = {
  public: "bg-muted text-muted-foreground",
  internal: "bg-primary/10 text-primary",
  confidential: "bg-warning/10 text-warning",
  restricted: "bg-destructive/10 text-destructive",
};

const statusColors = {
  compliant: "bg-success/10 text-success",
  "non-compliant": "bg-destructive/10 text-destructive",
  review: "bg-warning/10 text-warning",
};

export function DataAssetsTable() {
  const { dataAssets } = usePrivacy();

  const formatNumber = (n: number) => {
    if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`;
    if (n >= 1_000) return `${(n / 1_000).toFixed(0)}K`;
    return n.toString();
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.45 }}
      className="glass rounded-2xl overflow-hidden"
    >
      <div className="p-4 border-b border-border flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Database className="w-4 h-4 text-primary" />
          <h3 className="text-sm font-semibold text-foreground">Data Assets</h3>
          <span className="text-xs text-muted-foreground">({dataAssets.length})</span>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b border-border/50">
              <th className="text-left p-3 text-[11px] font-mono uppercase tracking-wider text-muted-foreground">Asset</th>
              <th className="text-left p-3 text-[11px] font-mono uppercase tracking-wider text-muted-foreground">Type</th>
              <th className="text-left p-3 text-[11px] font-mono uppercase tracking-wider text-muted-foreground">Classification</th>
              <th className="text-left p-3 text-[11px] font-mono uppercase tracking-wider text-muted-foreground">Records</th>
              <th className="text-left p-3 text-[11px] font-mono uppercase tracking-wider text-muted-foreground">Status</th>
              <th className="text-left p-3 text-[11px] font-mono uppercase tracking-wider text-muted-foreground">Last Audit</th>
            </tr>
          </thead>
          <tbody>
            {dataAssets.map((asset, i) => (
              <motion.tr
                key={asset.id}
                initial={{ opacity: 0, x: -8 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.45 + i * 0.05 }}
                className="border-b border-border/30 hover:bg-muted/20 transition-colors"
              >
                <td className="p-3">
                  <div className="flex items-center gap-2">
                    <Database className="w-3.5 h-3.5 text-muted-foreground" />
                    <span className="text-sm font-medium text-foreground">{asset.name}</span>
                  </div>
                </td>
                <td className="p-3 text-xs text-muted-foreground font-mono">{asset.type}</td>
                <td className="p-3">
                  <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${classColors[asset.classification]}`}>
                    {asset.classification}
                  </span>
                </td>
                <td className="p-3 text-sm font-mono text-foreground">{formatNumber(asset.records)}</td>
                <td className="p-3">
                  <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${statusColors[asset.complianceStatus]}`}>
                    {asset.complianceStatus}
                  </span>
                </td>
                <td className="p-3 text-xs text-muted-foreground font-mono">{asset.lastAudit}</td>
              </motion.tr>
            ))}
          </tbody>
        </table>
      </div>
    </motion.div>
  );
}
