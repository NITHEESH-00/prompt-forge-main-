import { useState, useRef, useEffect } from "react";
import { Terminal, X, ChevronDown, AlertCircle } from "lucide-react";
import type { LogEntry } from "./LivePreview";

interface ExecutionLogsProps {
  logs: LogEntry[];
  visible: boolean;
  onToggle: () => void;
  onClear: () => void;
}

const levelColors: Record<string, string> = {
  log: "text-foreground",
  info: "text-forge-cyan",
  warn: "text-forge-amber",
  error: "text-forge-red",
};

const levelBadge: Record<string, string> = {
  log: "text-muted-foreground",
  info: "text-forge-cyan",
  warn: "text-forge-amber",
  error: "text-forge-red",
};

export function ExecutionLogs({ logs, visible, onToggle, onClear }: ExecutionLogsProps) {
  const scrollRef = useRef<HTMLDivElement>(null);
  const errorCount = logs.filter(l => l.type === "error").length;

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [logs]);

  return (
    <div className={`border-t border-border flex flex-col transition-all ${visible ? 'h-48' : 'h-8'}`}>
      {/* Toggle bar */}
      <button
        onClick={onToggle}
        className="h-8 shrink-0 flex items-center justify-between px-3 glass-strong hover:bg-muted/30 transition-colors"
      >
        <div className="flex items-center gap-2">
          <Terminal className="w-3 h-3 text-muted-foreground" />
          <span className="text-[10px] font-mono uppercase tracking-wider text-muted-foreground">
            Execution Logs
          </span>
          {errorCount > 0 && (
            <span className="flex items-center gap-1 text-[10px] font-mono text-forge-red">
              <AlertCircle className="w-3 h-3" /> {errorCount}
            </span>
          )}
          {logs.length > 0 && errorCount === 0 && (
            <span className="text-[10px] font-mono text-muted-foreground/60">{logs.length}</span>
          )}
        </div>
        <ChevronDown className={`w-3 h-3 text-muted-foreground transition-transform ${visible ? 'rotate-180' : ''}`} />
      </button>

      {/* Log content */}
      {visible && (
        <div ref={scrollRef} className="flex-1 overflow-auto bg-background/80 font-mono text-[11px]">
          {logs.length === 0 ? (
            <div className="flex items-center justify-center h-full text-muted-foreground/40">
              No logs yet
            </div>
          ) : (
            <div className="p-2 space-y-0.5">
              {logs.map((log, i) => (
                <div key={i} className="flex items-start gap-2 py-0.5 px-1 rounded hover:bg-muted/20">
                  <span className={`text-[9px] uppercase font-bold w-10 shrink-0 mt-0.5 ${levelBadge[log.type]}`}>
                    {log.type}
                  </span>
                  <span className={`break-all ${levelColors[log.type]}`}>{log.message}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
