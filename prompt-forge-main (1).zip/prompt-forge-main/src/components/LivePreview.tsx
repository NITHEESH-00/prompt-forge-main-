import { useState, useCallback, useRef, useEffect } from "react";
import { Monitor, Tablet, Smartphone, RotateCcw } from "lucide-react";

interface ViewportSize {
  width: number;
  height: string;
  label: string;
  icon: any;
}

const viewports: ViewportSize[] = [
  { width: 0, height: "100%", label: "Desktop", icon: Monitor },
  { width: 768, height: "100%", label: "Tablet", icon: Tablet },
  { width: 375, height: "100%", label: "Mobile", icon: Smartphone },
];

interface LivePreviewProps {
  files: Array<{ path: string; content: string }>;
  onLog?: (entry: LogEntry) => void;
  isBuilding?: boolean;
}

export interface LogEntry {
  type: "log" | "error" | "warn" | "info";
  message: string;
  timestamp: number;
}

export function LivePreview({ files, onLog, isBuilding }: LivePreviewProps) {
  const [activeViewport, setActiveViewport] = useState(0);
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const [key, setKey] = useState(0);

  const buildSrcdoc = useCallback(() => {
    if (files.length === 0) return "";

    // Find entry files
    const indexHtml = files.find(f => f.path.match(/index\.html$/i));
    const appFile = files.find(f => f.path.match(/App\.(tsx|jsx|ts|js)$/i));
    const mainFile = files.find(f => f.path.match(/(main|index)\.(tsx|jsx|ts|js)$/i) && !f.path.match(/index\.html$/i));

    // Build blob URLs for importmap
    const blobs: Record<string, string> = {};
    files.forEach(f => {
      const ext = f.path.split('.').pop() || '';
      const mime = ['ts', 'tsx', 'js', 'jsx'].includes(ext) ? 'application/javascript' : 
                   ext === 'css' ? 'text/css' : 'text/plain';
      // For now, just include the raw content
      blobs[f.path] = f.content;
    });

    // Simple HTML wrapper showing the code
    if (indexHtml) {
      return indexHtml.content;
    }

    // Build a simple preview showing the file contents
    const allCode = files.map(f => 
      `<div style="margin-bottom:16px"><div style="color:#60a5fa;font-size:12px;margin-bottom:4px;font-family:monospace">${f.path}</div><pre style="background:#18181b;padding:12px;border-radius:8px;overflow-x:auto;font-size:12px;color:#e4e4e7;border:1px solid #27272a;margin:0"><code>${escapeHtml(f.content)}</code></pre></div>`
    ).join('');

    return `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { 
      background: #09090b; 
      color: #e4e4e7; 
      font-family: 'Inter', system-ui, sans-serif;
      padding: 24px;
    }
    h2 { font-size: 14px; color: #71717a; margin-bottom: 16px; font-family: monospace; }
  </style>
</head>
<body>
  <h2>Generated Files Preview</h2>
  ${allCode}
  <script>
    // Intercept console
    const origLog = console.log;
    const origErr = console.error;
    const origWarn = console.warn;
    const origInfo = console.info;
    function post(type, args) {
      try {
        window.parent.postMessage({ type: 'console', level: type, message: Array.from(args).map(a => typeof a === 'object' ? JSON.stringify(a) : String(a)).join(' ') }, '*');
      } catch(e) {}
    }
    console.log = function() { post('log', arguments); origLog.apply(console, arguments); };
    console.error = function() { post('error', arguments); origErr.apply(console, arguments); };
    console.warn = function() { post('warn', arguments); origWarn.apply(console, arguments); };
    console.info = function() { post('info', arguments); origInfo.apply(console, arguments); };
    window.onerror = function(msg) { post('error', [msg]); };
  </script>
</body>
</html>`;
  }, [files]);

  useEffect(() => {
    const handler = (e: MessageEvent) => {
      if (e.data?.type === 'console' && onLog) {
        onLog({
          type: e.data.level,
          message: e.data.message,
          timestamp: Date.now(),
        });
      }
    };
    window.addEventListener('message', handler);
    return () => window.removeEventListener('message', handler);
  }, [onLog]);

  const viewport = viewports[activeViewport];

  return (
    <div className="flex flex-col h-full bg-background">
      {/* Toolbar */}
      <div className="h-9 flex items-center justify-between px-3 border-b border-border glass-strong shrink-0">
        <div className="flex items-center gap-1">
          {viewports.map((vp, i) => (
            <button
              key={vp.label}
              onClick={() => setActiveViewport(i)}
              className={`p-1.5 rounded transition-colors ${
                activeViewport === i
                  ? "bg-primary/10 text-primary"
                  : "text-muted-foreground hover:text-foreground hover:bg-muted/50"
              }`}
              title={vp.label}
            >
              <vp.icon className="w-3.5 h-3.5" />
            </button>
          ))}
        </div>
        <div className="flex items-center gap-2">
          {viewport.width > 0 && (
            <span className="text-[10px] font-mono text-muted-foreground">{viewport.width}px</span>
          )}
          <button
            onClick={() => setKey(k => k + 1)}
            className="p-1.5 rounded text-muted-foreground hover:text-foreground hover:bg-muted/50 transition-colors"
            title="Refresh"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Preview area */}
      <div className="flex-1 flex items-start justify-center overflow-auto bg-background/50 p-2">
        <div
          className="h-full border border-border rounded-lg overflow-hidden bg-background transition-all duration-300"
          style={{ width: viewport.width > 0 ? `${viewport.width}px` : '100%', maxWidth: '100%' }}
        >
          {isBuilding ? (
            <div className="flex items-center justify-center h-full">
              <div className="text-center space-y-3">
                <div className="w-8 h-8 border-2 border-primary/30 border-t-primary rounded-full animate-spin mx-auto" />
                <p className="text-xs font-mono text-muted-foreground">Building runtime...</p>
              </div>
            </div>
          ) : files.length === 0 ? (
            <div className="flex items-center justify-center h-full">
              <p className="text-xs font-mono text-muted-foreground">No preview available</p>
            </div>
          ) : (
            <iframe
              key={key}
              ref={iframeRef}
              srcDoc={buildSrcdoc()}
              className="w-full h-full border-0"
              sandbox="allow-scripts allow-same-origin"
              title="Preview"
            />
          )}
        </div>
      </div>
    </div>
  );
}

function escapeHtml(str: string): string {
  return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}
