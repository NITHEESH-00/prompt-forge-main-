import { motion } from "framer-motion";
import { LucideIcon, TrendingUp, TrendingDown, Minus } from "lucide-react";

interface MetricCardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  icon: LucideIcon;
  trend?: "up" | "down" | "stable";
  trendValue?: string;
  accentColor?: string;
  delay?: number;
}

const trendIcons = { up: TrendingUp, down: TrendingDown, stable: Minus };
const trendColors = {
  up: "text-success",
  down: "text-destructive",
  stable: "text-muted-foreground",
};

export function MetricCard({ title, value, subtitle, icon: Icon, trend, trendValue, accentColor = "primary", delay = 0 }: MetricCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay, duration: 0.4 }}
      className="glass rounded-2xl p-5 group hover:glow-border transition-all duration-300 hover:shadow-xl"
    >
      <div className="flex items-start justify-between mb-4">
        <div className={`w-10 h-10 rounded-xl bg-${accentColor}/10 border border-${accentColor}/20 flex items-center justify-center group-hover:scale-110 transition-transform duration-300`}>
          <Icon className={`w-5 h-5 text-${accentColor}`} />
        </div>
        {trend && (
          <div className={`flex items-center gap-1 text-xs font-medium ${trendColors[trend]}`}>
            {(() => {
              const TIcon = trendIcons[trend];
              return <TIcon className="w-3 h-3" />;
            })()}
            {trendValue}
          </div>
        )}
      </div>
      <p className="text-3xl font-bold font-mono text-foreground tracking-tight">{value}</p>
      <p className="text-xs text-muted-foreground mt-1">{title}</p>
      {subtitle && <p className="text-[10px] text-muted-foreground/60 mt-0.5">{subtitle}</p>}
    </motion.div>
  );
}
