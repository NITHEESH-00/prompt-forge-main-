import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { AlertTriangle, Shield, ChevronDown, ChevronUp, Filter } from "lucide-react";
import { usePrivacy, type RiskItem } from "@/context/PrivacyContext";
import { Button } from "@/components/ui/button";

const severityConfig = {
  critical: { color: "bg-destructive/10 text-destructive border-destructive/20", dot: "bg-destructive" },
  high: { color: "bg-warning/10 text-warning border-warning/20", dot: "bg-warning" },
  medium: { color: "bg-forge-amber/10 text-forge-amber border-forge-amber/20", dot: "bg-forge-amber" },
  low: { color: "bg-muted text-muted-foreground border-border", dot: "bg-muted-foreground" },
};

const statusConfig = {
  active: "bg-destructive/10 text-destructive",
  mitigated: "bg-success/10 text-success",
  acknowledged: "bg-warning/10 text-warning",
};

export function RiskTable() {
  const { activeRisks } = usePrivacy();
  const [sortField, setSortField] = useState<"severity" | "detectedAt">("severity");
  const [sortDir, setSortDir] = useState<"asc" | "desc">("desc");
  const [filter, setFilter] = useState<string>("all");
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const severityOrder = { critical: 4, high: 3, medium: 2, low: 1 };

  const sorted = [...activeRisks]
    .filter((r) => filter === "all" || r.severity === filter)
    .sort((a, b) => {
      if (sortField === "severity") {
        const diff = severityOrder[b.severity] - severityOrder[a.severity];
        return sortDir === "desc" ? diff : -diff;
      }
      const diff = new Date(b.detectedAt).getTime() - new Date(a.detectedAt).getTime();
      return sortDir === "desc" ? diff : -diff;
    });

  const toggleSort = (field: typeof sortField) => {
    if (sortField === field) setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    else { setSortField(field); setSortDir("desc"); }
  };

  const SortIcon = sortDir === "desc" ? ChevronDown : ChevronUp;

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.3 }}
      className="glass rounded-2xl overflow-hidden"
    >
      <div className="p-4 border-b border-border flex items-center justify-between">
        <div className="flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 text-warning" />
          <h3 className="text-sm font-semibold text-foreground">Active Risks</h3>
          <span className="text-xs text-muted-foreground">({sorted.length})</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1">
            {["all", "critical", "high", "medium"].map((f) => (
              <Button
                key={f}
                variant={filter === f ? "default" : "ghost"}
                size="sm"
                className="h-7 text-xs rounded-lg capitalize"
                onClick={() => setFilter(f)}
              >
                {f}
              </Button>
            ))}
          </div>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b border-border/50">
              <th className="text-left p-3 text-[11px] font-mono uppercase tracking-wider text-muted-foreground">Risk</th>
              <th
                className="text-left p-3 text-[11px] font-mono uppercase tracking-wider text-muted-foreground cursor-pointer hover:text-foreground transition-colors"
                onClick={() => toggleSort("severity")}
              >
                <span className="flex items-center gap-1">
                  Severity {sortField === "severity" && <SortIcon className="w-3 h-3" />}
                </span>
              </th>
              <th className="text-left p-3 text-[11px] font-mono uppercase tracking-wider text-muted-foreground">Category</th>
              <th className="text-left p-3 text-[11px] font-mono uppercase tracking-wider text-muted-foreground">Status</th>
              <th
                className="text-left p-3 text-[11px] font-mono uppercase tracking-wider text-muted-foreground cursor-pointer hover:text-foreground transition-colors"
                onClick={() => toggleSort("detectedAt")}
              >
                <span className="flex items-center gap-1">
                  Detected {sortField === "detectedAt" && <SortIcon className="w-3 h-3" />}
                </span>
              </th>
            </tr>
          </thead>
          <tbody>
            {sorted.map((risk, i) => {
              const sev = severityConfig[risk.severity];
              const expanded = expandedId === risk.id;
              return (
                <motion.tr
                  key={risk.id}
                  initial={{ opacity: 0, x: -8 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.05 }}
                  className="border-b border-border/30 hover:bg-muted/20 transition-colors cursor-pointer"
                  onClick={() => setExpandedId(expanded ? null : risk.id)}
                >
                  <td className="p-3">
                    <div>
                      <p className="text-sm text-foreground font-medium">{risk.title}</p>
                      <AnimatePresence>
                        {expanded && (
                          <motion.p
                            initial={{ height: 0, opacity: 0 }}
                            animate={{ height: "auto", opacity: 1 }}
                            exit={{ height: 0, opacity: 0 }}
                            className="text-xs text-muted-foreground mt-1 overflow-hidden"
                          >
                            {risk.description}
                          </motion.p>
                        )}
                      </AnimatePresence>
                    </div>
                  </td>
                  <td className="p-3">
                    <span className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-xs font-medium border ${sev.color}`}>
                      <span className={`w-1.5 h-1.5 rounded-full ${sev.dot}`} />
                      {risk.severity}
                    </span>
                  </td>
                  <td className="p-3 text-xs text-muted-foreground">{risk.category}</td>
                  <td className="p-3">
                    <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${statusConfig[risk.status]}`}>
                      {risk.status}
                    </span>
                  </td>
                  <td className="p-3 text-xs text-muted-foreground font-mono">
                    {new Date(risk.detectedAt).toLocaleDateString()}
                  </td>
                </motion.tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </motion.div>
  );
}
