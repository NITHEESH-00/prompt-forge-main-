import { motion } from "framer-motion";
import { Loader2, Anvil } from "lucide-react";

interface StatusOverlayProps {
  status: "architecting" | "building" | "failed";
  message?: string;
}

export function StatusOverlay({ status, message }: StatusOverlayProps) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="absolute inset-0 z-20 flex items-center justify-center"
      style={{ backdropFilter: "blur(8px)", WebkitBackdropFilter: "blur(8px)" }}
    >
      <div className="bg-card/90 border border-border rounded-2xl p-8 flex flex-col items-center gap-4 glow-border max-w-sm text-center">
        {status === "failed" ? (
          <div className="w-12 h-12 rounded-full bg-forge-red/10 border border-forge-red/20 flex items-center justify-center">
            <span className="text-forge-red font-mono text-lg">!</span>
          </div>
        ) : (
          <div className="relative">
            <div className="w-12 h-12 rounded-full bg-primary/10 border border-primary/20 flex items-center justify-center">
              <Anvil className="w-6 h-6 text-primary" />
            </div>
            <Loader2 className="w-14 h-14 text-primary/30 animate-spin absolute -top-1 -left-1" />
          </div>
        )}
        <div>
          <p className="font-mono text-sm text-foreground font-medium">
            {status === "architecting" && "Architecting Project..."}
            {status === "building" && "Building Runtime..."}
            {status === "failed" && "Build Failed"}
          </p>
          {message && (
            <p className="text-xs text-muted-foreground mt-1 font-mono">{message}</p>
          )}
        </div>
      </div>
    </motion.div>
  );
}
