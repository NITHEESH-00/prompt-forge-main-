import { createContext, useContext, useState, ReactNode, useCallback, useEffect } from "react";

export interface RiskItem {
  id: string;
  title: string;
  severity: "critical" | "high" | "medium" | "low";
  category: string;
  status: "active" | "mitigated" | "acknowledged";
  detectedAt: string;
  description: string;
}

export interface DataAsset {
  id: string;
  name: string;
  type: string;
  classification: "public" | "internal" | "confidential" | "restricted";
  records: number;
  lastAudit: string;
  complianceStatus: "compliant" | "non-compliant" | "review";
}

export interface ActivityItem {
  id: string;
  action: string;
  user: string;
  resource: string;
  timestamp: string;
  type: "info" | "warning" | "success" | "error";
}

export interface ComplianceMetric {
  label: string;
  score: number;
  trend: "up" | "down" | "stable";
  change: number;
}

interface PrivacyContextType {
  privacyScore: number;
  gdprReadiness: number;
  activeRisks: RiskItem[];
  dataAssets: DataAsset[];
  recentActivity: ActivityItem[];
  complianceMetrics: ComplianceMetric[];
  totalDataSubjects: number;
  pendingRequests: number;
  refreshData: () => void;
}

const mockRisks: RiskItem[] = [
  { id: "r1", title: "Unencrypted PII in staging DB", severity: "critical", category: "Data Protection", status: "active", detectedAt: "2026-03-25T10:30:00Z", description: "Personal data found without encryption in staging environment." },
  { id: "r2", title: "Third-party cookie without consent", severity: "high", category: "Consent Management", status: "active", detectedAt: "2026-03-24T14:15:00Z", description: "Marketing cookies deployed without valid user consent." },
  { id: "r3", title: "Data retention policy exceeded", severity: "medium", category: "Data Lifecycle", status: "acknowledged", detectedAt: "2026-03-23T09:00:00Z", description: "Customer records kept beyond 24-month retention window." },
  { id: "r4", title: "Missing DPIA for new feature", severity: "high", category: "Impact Assessment", status: "active", detectedAt: "2026-03-22T16:45:00Z", description: "New analytics feature launched without privacy impact assessment." },
  { id: "r5", title: "Vendor contract missing DPA clause", severity: "medium", category: "Third-Party Risk", status: "mitigated", detectedAt: "2026-03-20T11:20:00Z", description: "Cloud provider agreement lacks data processing addendum." },
];

const mockDataAssets: DataAsset[] = [
  { id: "d1", name: "Customer Database", type: "PostgreSQL", classification: "confidential", records: 1248500, lastAudit: "2026-03-15", complianceStatus: "compliant" },
  { id: "d2", name: "Marketing Analytics", type: "BigQuery", classification: "internal", records: 5820000, lastAudit: "2026-03-10", complianceStatus: "review" },
  { id: "d3", name: "HR Records", type: "PostgreSQL", classification: "restricted", records: 3420, lastAudit: "2026-03-18", complianceStatus: "compliant" },
  { id: "d4", name: "Product Telemetry", type: "MongoDB", classification: "internal", records: 12400000, lastAudit: "2026-02-28", complianceStatus: "non-compliant" },
  { id: "d5", name: "Support Tickets", type: "PostgreSQL", classification: "confidential", records: 89200, lastAudit: "2026-03-12", complianceStatus: "compliant" },
  { id: "d6", name: "Payment Records", type: "Stripe Vault", classification: "restricted", records: 452000, lastAudit: "2026-03-20", complianceStatus: "compliant" },
];

const mockActivity: ActivityItem[] = [
  { id: "a1", action: "Data access request fulfilled", user: "System", resource: "Subject #4821", timestamp: "2026-03-26T09:15:00Z", type: "success" },
  { id: "a2", action: "Risk assessment flagged", user: "AI Monitor", resource: "Staging DB", timestamp: "2026-03-26T08:42:00Z", type: "warning" },
  { id: "a3", action: "DPIA completed", user: "Jane Cooper", resource: "Analytics Module", timestamp: "2026-03-25T17:30:00Z", type: "success" },
  { id: "a4", action: "Consent record updated", user: "API Gateway", resource: "User #12847", timestamp: "2026-03-25T16:10:00Z", type: "info" },
  { id: "a5", action: "Encryption key rotated", user: "System", resource: "Production DB", timestamp: "2026-03-25T12:00:00Z", type: "info" },
  { id: "a6", action: "Breach simulation completed", user: "Security Team", resource: "Global", timestamp: "2026-03-25T10:00:00Z", type: "success" },
  { id: "a7", action: "Vendor audit failed", user: "AI Monitor", resource: "Analytics Vendor", timestamp: "2026-03-24T15:30:00Z", type: "error" },
  { id: "a8", action: "Data deletion request received", user: "DSAR Portal", resource: "Subject #9102", timestamp: "2026-03-24T14:15:00Z", type: "warning" },
];

const mockComplianceMetrics: ComplianceMetric[] = [
  { label: "GDPR", score: 87, trend: "up", change: 3 },
  { label: "CCPA", score: 92, trend: "up", change: 5 },
  { label: "HIPAA", score: 78, trend: "down", change: -2 },
  { label: "SOC 2", score: 95, trend: "stable", change: 0 },
];

const PrivacyContext = createContext<PrivacyContextType>({
  privacyScore: 0,
  gdprReadiness: 0,
  activeRisks: [],
  dataAssets: [],
  recentActivity: [],
  complianceMetrics: [],
  totalDataSubjects: 0,
  pendingRequests: 0,
  refreshData: () => {},
});

export function PrivacyProvider({ children }: { children: ReactNode }) {
  const [privacyScore, setPrivacyScore] = useState(0);
  const [gdprReadiness, setGdprReadiness] = useState(0);

  useEffect(() => {
    const timer = setTimeout(() => {
      setPrivacyScore(84);
      setGdprReadiness(87);
    }, 300);
    return () => clearTimeout(timer);
  }, []);

  const refreshData = useCallback(() => {
    setPrivacyScore((p) => Math.min(100, p + Math.floor(Math.random() * 3)));
    setGdprReadiness((g) => Math.min(100, g + Math.floor(Math.random() * 2)));
  }, []);

  return (
    <PrivacyContext.Provider
      value={{
        privacyScore,
        gdprReadiness,
        activeRisks: mockRisks,
        dataAssets: mockDataAssets,
        recentActivity: mockActivity,
        complianceMetrics: mockComplianceMetrics,
        totalDataSubjects: 1248500,
        pendingRequests: 12,
        refreshData,
      }}
    >
      {children}
    </PrivacyContext.Provider>
  );
}

export const usePrivacy = () => useContext(PrivacyContext);
