import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { AppLayout } from "@/components/AppLayout";
import { motion } from "framer-motion";
import { Shield, Users, Activity, Loader2 } from "lucide-react";
import { toast } from "sonner";

interface AuditEntry {
  id: number;
  action: string;
  resource: string | null;
  success: boolean | null;
  created_at: string;
  user_id: string | null;
}

export default function Admin() {
  const { isAdmin } = useAuth();
  const [auditLogs, setAuditLogs] = useState<AuditEntry[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!isAdmin) return;
    supabase
      .from("audit_logs")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(50)
      .then(({ data, error }) => {
        if (error) toast.error("Failed to load audit logs");
        setAuditLogs(data ?? []);
        setLoading(false);
      });
  }, [isAdmin]);

  if (!isAdmin) {
    return (
      <AppLayout>
        <div className="flex items-center justify-center h-full">
          <div className="text-center text-muted-foreground font-mono">
            <Shield className="w-10 h-10 mx-auto mb-4 opacity-30" />
            <p className="text-sm">Access denied. Admin role required.</p>
          </div>
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div className="p-6 max-w-5xl mx-auto space-y-6">
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
          <h1 className="text-xl font-bold font-mono text-foreground">System Admin</h1>
          <p className="text-xs text-muted-foreground mt-1">Audit logs and system overview</p>
        </motion.div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="glass rounded-xl p-5">
            <div className="flex items-center gap-2 mb-2">
              <Users className="w-4 h-4 text-forge-cyan" />
              <span className="font-mono text-[11px] uppercase tracking-wider text-muted-foreground">User Management</span>
            </div>
            <p className="text-sm text-muted-foreground font-mono">Manage users via Cloud dashboard</p>
          </div>
          <div className="glass rounded-xl p-5">
            <div className="flex items-center gap-2 mb-2">
              <Activity className="w-4 h-4 text-forge-green" />
              <span className="font-mono text-[11px] uppercase tracking-wider text-muted-foreground">Audit Events</span>
            </div>
            <p className="text-3xl font-bold font-mono text-foreground">{auditLogs.length}</p>
          </div>
        </div>

        <div>
          <h2 className="text-xs font-mono uppercase tracking-wider text-muted-foreground mb-4">Audit Log</h2>
          {loading ? (
            <div className="flex items-center gap-2 text-muted-foreground font-mono text-sm justify-center py-8">
              <Loader2 className="w-4 h-4 animate-spin" /> Loading...
            </div>
          ) : auditLogs.length === 0 ? (
            <div className="glass rounded-xl p-8 text-center">
              <p className="text-sm text-muted-foreground font-mono">No logs yet</p>
            </div>
          ) : (
            <div className="glass rounded-xl overflow-hidden">
              <div className="overflow-auto max-h-96">
                <table className="w-full text-xs font-mono">
                  <thead className="bg-muted/20 sticky top-0">
                    <tr>
                      <th className="text-left p-3 text-muted-foreground font-medium">Time</th>
                      <th className="text-left p-3 text-muted-foreground font-medium">Action</th>
                      <th className="text-left p-3 text-muted-foreground font-medium">Resource</th>
                      <th className="text-left p-3 text-muted-foreground font-medium">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {auditLogs.map((log) => (
                      <tr key={log.id} className="border-t border-border/50">
                        <td className="p-3 text-muted-foreground">{new Date(log.created_at).toLocaleString()}</td>
                        <td className="p-3 text-foreground">{log.action}</td>
                        <td className="p-3 text-muted-foreground">{log.resource || "—"}</td>
                        <td className="p-3">
                          <span className={log.success ? "text-forge-green" : "text-forge-red"}>
                            {log.success ? "OK" : "FAIL"}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      </div>
    </AppLayout>
  );
}
