import { useAuth } from "@/hooks/useAuth";
import { usePrivacy } from "@/context/PrivacyContext";
import { AppLayout } from "@/components/AppLayout";
import { DashboardHeader } from "@/components/DashboardHeader";
import { ScoreGauge } from "@/components/ScoreGauge";
import { MetricCard } from "@/components/MetricCard";
import { RiskTable } from "@/components/RiskTable";
import { ActivityFeed } from "@/components/ActivityFeed";
import { ComplianceChart } from "@/components/ComplianceChart";
import { DataAssetsTable } from "@/components/DataAssetsTable";
import { motion } from "framer-motion";
import { Shield, Users, FileWarning, Clock, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Dashboard() {
  const { profile } = useAuth();
  const { privacyScore, gdprReadiness, activeRisks, totalDataSubjects, pendingRequests, refreshData } = usePrivacy();

  const criticalCount = activeRisks.filter((r) => r.severity === "critical" || r.severity === "high").length;

  return (
    <AppLayout>
      <DashboardHeader />
      <div className="p-4 lg:p-6 max-w-[1400px] mx-auto space-y-6 overflow-auto">
        {/* Welcome & Refresh */}
        <div className="flex items-center justify-between">
          <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}>
            <h1 className="text-xl lg:text-2xl font-bold text-foreground">
              Welcome back, <span className="text-gradient-primary">{profile?.display_name || "Admin"}</span>
            </h1>
            <p className="text-sm text-muted-foreground mt-1">Privacy & compliance overview</p>
          </motion.div>
          <Button variant="outline" size="sm" className="gap-2 rounded-xl" onClick={refreshData}>
            <RefreshCw className="w-3.5 h-3.5" /> Refresh
          </Button>
        </div>

        {/* Score gauges + metrics row */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
          {/* Gauges */}
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="lg:col-span-4 glass rounded-2xl p-6 flex items-center justify-around"
          >
            <ScoreGauge score={privacyScore} label="Privacy Score" colorClass="text-primary" />
            <ScoreGauge score={gdprReadiness} label="GDPR Ready" colorClass="text-success" />
          </motion.div>

          {/* Metric cards */}
          <div className="lg:col-span-8 grid grid-cols-2 lg:grid-cols-4 gap-4">
            <MetricCard
              title="Active Risks"
              value={activeRisks.length}
              icon={FileWarning}
              accentColor="warning"
              trend="down"
              trendValue="-2"
              delay={0.15}
            />
            <MetricCard
              title="Critical/High"
              value={criticalCount}
              icon={Shield}
              accentColor="destructive"
              trend="down"
              trendValue="-1"
              delay={0.2}
            />
            <MetricCard
              title="Data Subjects"
              value="1.2M"
              subtitle="Across all systems"
              icon={Users}
              accentColor="primary"
              trend="up"
              trendValue="+4.2%"
              delay={0.25}
            />
            <MetricCard
              title="Pending DSARs"
              value={pendingRequests}
              subtitle="Avg 2.3 day response"
              icon={Clock}
              accentColor="accent"
              trend="stable"
              trendValue="0"
              delay={0.3}
            />
          </div>
        </div>

        {/* Risk table */}
        <RiskTable />

        {/* Compliance + Activity row */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <ComplianceChart />
          <ActivityFeed />
        </div>

        {/* Data assets */}
        <DataAssetsTable />
      </div>
    </AppLayout>
  );
}
