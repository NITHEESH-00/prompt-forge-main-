import { useNavigate, Link } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { motion } from "framer-motion";
import {
  Anvil,
  ArrowRight,
  Sparkles,
  Code2,
  Monitor,
  Tablet,
  Smartphone,
  Zap,
  Shield,
  Layers,
  MessageSquare,
  Eye,
  Terminal,
  GitBranch,
  ChevronRight,
} from "lucide-react";
import { Button } from "@/components/ui/button";

const features = [
  {
    icon: Code2,
    title: "AI Code Generation",
    description:
      "Describe your app in plain language. Our AI architect generates production-ready React code instantly.",
  },
  {
    icon: Eye,
    title: "Live Preview",
    description:
      "See your app running in real-time with responsive viewport switching — Desktop, Tablet, and Mobile.",
  },
  {
    icon: Terminal,
    title: "Execution Logs",
    description:
      "Stream console output directly from the virtual runtime. Debug errors without leaving the IDE.",
  },
  {
    icon: MessageSquare,
    title: "AI Architect Chat",
    description:
      "Iteratively refine your code through conversation. The AI understands context and makes targeted updates.",
  },
  {
    icon: GitBranch,
    title: "Version Checkpoints",
    description:
      "Save snapshots of your project at any point. Restore previous versions with a single click.",
  },
  {
    icon: Layers,
    title: "Multi-File Projects",
    description:
      "Generate complete applications with multiple files, components, and styles — all managed in one place.",
  },
];

const stats = [
  { value: "10x", label: "Faster Development" },
  { value: "<3s", label: "Generation Time" },
  { value: "100%", label: "Cloud-Based" },
];

export default function Index() {
  const { user } = useAuth();
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 border-b border-border/50 bg-background/80 backdrop-blur-xl">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2">
            <Anvil className="w-6 h-6 text-primary" />
            <span className="text-lg font-bold tracking-tight">Prompt Forge</span>
          </Link>
          <div className="hidden md:flex items-center gap-8">
            <a href="#features" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              Features
            </a>
            <a href="#how-it-works" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              How It Works
            </a>
            <a href="#preview" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              Preview
            </a>
          </div>
          <div className="flex items-center gap-3">
            {user ? (
              <Button onClick={() => navigate("/dashboard")} size="sm">
                Dashboard <ArrowRight className="w-4 h-4 ml-1" />
              </Button>
            ) : (
              <>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => navigate("/auth")}
                  className="text-muted-foreground hover:text-foreground"
                >
                  Log in
                </Button>
                <Button onClick={() => navigate("/auth")} size="sm">
                  Get Started
                </Button>
              </>
            )}
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative pt-32 pb-20 px-6 overflow-hidden">
        {/* Background glow */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[800px] h-[600px] bg-primary/5 rounded-full blur-[120px]" />
        </div>

        <div className="max-w-5xl mx-auto text-center relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-primary/20 bg-primary/5 mb-8">
              <Sparkles className="w-4 h-4 text-primary" />
              <span className="text-sm text-primary font-medium">AI-Powered Code Generation</span>
            </div>
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="text-5xl sm:text-6xl lg:text-7xl font-bold tracking-tight leading-[1.1] mb-6"
          >
            Describe it.
            <br />
            <span className="text-primary">We build it.</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="text-lg sm:text-xl text-muted-foreground max-w-2xl mx-auto mb-10"
          >
            Turn your ideas into stunning, responsive websites in seconds. Just describe what you want
            — our AI handles the rest.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-4"
          >
            <Button
              size="lg"
              className="text-base px-8 h-12"
              onClick={() => navigate(user ? "/new-project" : "/auth")}
            >
              Start Building Free <ArrowRight className="w-5 h-5 ml-2" />
            </Button>
            <Button
              variant="outline"
              size="lg"
              className="text-base px-8 h-12"
              onClick={() => {
                document.getElementById("features")?.scrollIntoView({ behavior: "smooth" });
              }}
            >
              See Features
            </Button>
          </motion.div>

          {/* Stats */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.5 }}
            className="flex items-center justify-center gap-12 mt-16"
          >
            {stats.map((s) => (
              <div key={s.label} className="text-center">
                <p className="text-2xl sm:text-3xl font-bold text-primary">{s.value}</p>
                <p className="text-xs sm:text-sm text-muted-foreground mt-1">{s.label}</p>
              </div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* IDE Preview Mockup */}
      <section id="preview" className="px-6 pb-24">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="max-w-5xl mx-auto"
        >
          <div className="rounded-xl border border-border overflow-hidden bg-card shadow-2xl shadow-primary/5">
            {/* Browser chrome */}
            <div className="h-10 flex items-center px-4 bg-muted/30 border-b border-border gap-2">
              <div className="flex gap-1.5">
                <div className="w-3 h-3 rounded-full bg-red-500/80" />
                <div className="w-3 h-3 rounded-full bg-yellow-500/80" />
                <div className="w-3 h-3 rounded-full bg-green-500/80" />
              </div>
              <div className="flex-1 flex justify-center">
                <div className="px-4 py-1 rounded-md bg-background/50 border border-border text-xs font-mono text-muted-foreground">
                  promptforge.ai/preview
                </div>
              </div>
            </div>
            {/* IDE content mockup */}
            <div className="flex h-[400px]">
              {/* Sidebar */}
              <div className="w-48 border-r border-border bg-background/50 p-3 hidden sm:block">
                <p className="text-[10px] font-mono uppercase tracking-wider text-muted-foreground/50 mb-3">
                  Explorer
                </p>
                {["App.tsx", "index.css", "Header.tsx", "Hero.tsx", "Footer.tsx"].map((f, i) => (
                  <div
                    key={f}
                    className={`flex items-center gap-2 px-2 py-1.5 rounded text-[11px] font-mono ${
                      i === 0 ? "bg-primary/10 text-primary" : "text-muted-foreground"
                    }`}
                  >
                    <span className="text-[10px]">⚛</span>
                    {f}
                  </div>
                ))}
              </div>
              {/* Editor */}
              <div className="flex-1 p-4 font-mono text-xs leading-relaxed overflow-hidden bg-background/30">
                <div className="text-muted-foreground/40">
                  {[
                    <span key="1"><span className="text-purple-400">import</span> React <span className="text-purple-400">from</span> <span className="text-green-400">'react'</span>;</span>,
                    <span key="2"><span className="text-purple-400">import</span> {'{ Header }'} <span className="text-purple-400">from</span> <span className="text-green-400">'./Header'</span>;</span>,
                    <span key="3">&nbsp;</span>,
                    <span key="4"><span className="text-blue-400">export default function</span> <span className="text-yellow-300">App</span>() {'{'}</span>,
                    <span key="5">  <span className="text-purple-400">return</span> (</span>,
                    <span key="6">    <span className="text-blue-300">{'<div className="app">'}</span></span>,
                    <span key="7">      <span className="text-blue-300">{'<Header />'}</span></span>,
                    <span key="8">      <span className="text-blue-300">{'<Hero />'}</span></span>,
                    <span key="9">      <span className="text-blue-300">{'<Footer />'}</span></span>,
                    <span key="10">    <span className="text-blue-300">{'</div>'}</span></span>,
                    <span key="11">  );</span>,
                    <span key="12">{'}'}</span>,
                  ].map((line, i) => (
                    <div key={i} className="flex">
                      <span className="w-8 text-right mr-4 text-muted-foreground/20 select-none">{i + 1}</span>
                      <span className="text-foreground/70">{line}</span>
                    </div>
                  ))}
                </div>
              </div>
              {/* Preview pane */}
              <div className="w-[280px] border-l border-border bg-background/50 hidden md:flex flex-col">
                <div className="h-8 flex items-center gap-1 px-3 border-b border-border">
                  <Monitor className="w-3 h-3 text-primary" />
                  <Tablet className="w-3 h-3 text-muted-foreground" />
                  <Smartphone className="w-3 h-3 text-muted-foreground" />
                </div>
                <div className="flex-1 flex items-center justify-center p-4">
                  <div className="text-center space-y-2">
                    <div className="w-20 h-2 bg-primary/30 rounded mx-auto" />
                    <div className="w-32 h-3 bg-primary/20 rounded mx-auto" />
                    <div className="w-24 h-2 bg-muted/30 rounded mx-auto" />
                    <div className="mt-4 w-16 h-6 bg-primary/20 rounded mx-auto" />
                  </div>
                </div>
              </div>
            </div>
            {/* Terminal bar */}
            <div className="h-8 flex items-center px-4 border-t border-border bg-muted/20">
              <Terminal className="w-3 h-3 text-green-400 mr-2" />
              <span className="text-[10px] font-mono text-green-400/70">✓ Build complete — 5 files generated in 2.3s</span>
            </div>
          </div>
        </motion.div>
      </section>

      {/* Features Section */}
      <section id="features" className="px-6 py-24 border-t border-border/50">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl sm:text-4xl font-bold mb-4">
              Everything you need to <span className="text-primary">build faster</span>
            </h2>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              A complete cloud IDE with AI-powered code generation, live preview, and real-time debugging.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((f, i) => (
              <motion.div
                key={f.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="group p-6 rounded-xl border border-border bg-card/50 hover:bg-card hover:border-primary/20 transition-all duration-300"
              >
                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                  <f.icon className="w-5 h-5 text-primary" />
                </div>
                <h3 className="text-base font-semibold mb-2">{f.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{f.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section id="how-it-works" className="px-6 py-24 border-t border-border/50">
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl sm:text-4xl font-bold mb-4">
              Three steps to your <span className="text-primary">next project</span>
            </h2>
          </motion.div>

          <div className="space-y-12">
            {[
              {
                step: "01",
                title: "Describe Your Vision",
                desc: "Write a prompt describing the app you want. Be as detailed or as simple as you like.",
                icon: MessageSquare,
              },
              {
                step: "02",
                title: "AI Generates Code",
                desc: "Our AI architect creates a complete multi-file project with components, styles, and logic.",
                icon: Zap,
              },
              {
                step: "03",
                title: "Preview & Iterate",
                desc: "See your app running live. Edit code in the Monaco editor or chat with the AI to refine it.",
                icon: Eye,
              },
            ].map((item, i) => (
              <motion.div
                key={item.step}
                initial={{ opacity: 0, x: i % 2 === 0 ? -20 : 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                className="flex items-start gap-6"
              >
                <div className="shrink-0 w-12 h-12 rounded-xl bg-primary/10 border border-primary/20 flex items-center justify-center">
                  <span className="text-lg font-bold text-primary font-mono">{item.step}</span>
                </div>
                <div>
                  <h3 className="text-xl font-semibold mb-1">{item.title}</h3>
                  <p className="text-muted-foreground">{item.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="px-6 py-24 border-t border-border/50">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="max-w-3xl mx-auto text-center"
        >
          <h2 className="text-3xl sm:text-4xl font-bold mb-4">
            Ready to start <span className="text-primary">building</span>?
          </h2>
          <p className="text-muted-foreground text-lg mb-8">
            Join developers who are shipping 10x faster with AI-powered code generation.
          </p>
          <Button
            size="lg"
            className="text-base px-10 h-12"
            onClick={() => navigate(user ? "/new-project" : "/auth")}
          >
            Start Building Free <ArrowRight className="w-5 h-5 ml-2" />
          </Button>
        </motion.div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border/50 py-8 px-6">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Anvil className="w-4 h-4 text-primary/50" />
            <span className="text-sm font-mono text-muted-foreground">Prompt Forge</span>
          </div>
          <p className="text-xs text-muted-foreground/50">
            © {new Date().getFullYear()} Prompt Forge. Built with AI.
          </p>
        </div>
      </footer>
    </div>
  );
}
