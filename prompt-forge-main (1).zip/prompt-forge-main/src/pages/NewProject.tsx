import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { AppLayout } from "@/components/AppLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { motion } from "framer-motion";
import { Sparkles, Loader2, Anvil } from "lucide-react";

export default function NewProject() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({
    title: "",
    description: "",
    prompt: "",
    language: "typescript",
    framework: "react",
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    setLoading(true);

    try {
      const { data: project, error } = await supabase
        .from("projects")
        .insert({
          user_id: user.id,
          title: form.title,
          description: form.description,
          prompt: { text: form.prompt, language: form.language, framework: form.framework },
          language: form.language,
          framework: form.framework,
          status: "PROCESSING",
        })
        .select()
        .single();

      if (error) throw error;

      const { error: genError } = await supabase.functions.invoke("generate-code", {
        body: {
          projectId: project.id,
          prompt: form.prompt,
          language: form.language,
          framework: form.framework,
        },
      });

      if (genError) {
        await supabase.from("projects").update({ status: "FAILED", error_message: genError.message }).eq("id", project.id);
        toast.error("Generation failed: " + genError.message);
      } else {
        toast.success("Project forged successfully!");
      }

      navigate(`/project/${project.id}`);
    } catch (err: any) {
      toast.error(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <AppLayout>
      <div className="p-6 max-w-2xl mx-auto">
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 rounded-xl bg-primary/10 border border-primary/20 flex items-center justify-center">
              <Anvil className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h1 className="text-xl font-bold font-mono text-foreground">New Project</h1>
              <p className="text-xs text-muted-foreground">Describe what you want to build</p>
            </div>
          </div>
        </motion.div>

        <form onSubmit={handleSubmit} className="space-y-5">
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 }} className="glass rounded-xl p-5 space-y-4">
            <div className="space-y-1.5">
              <Label className="font-mono text-[11px] uppercase tracking-wider text-muted-foreground">Project Name</Label>
              <Input
                value={form.title}
                onChange={(e) => setForm({ ...form, title: e.target.value })}
                placeholder="My Awesome App"
                required
                className="bg-muted/30 border-border font-mono text-sm h-10"
              />
            </div>

            <div className="space-y-1.5">
              <Label className="font-mono text-[11px] uppercase tracking-wider text-muted-foreground">Description</Label>
              <Input
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
                placeholder="A brief description"
                className="bg-muted/30 border-border font-mono text-sm h-10"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label className="font-mono text-[11px] uppercase tracking-wider text-muted-foreground">Language</Label>
                <Select value={form.language} onValueChange={(v) => setForm({ ...form, language: v })}>
                  <SelectTrigger className="bg-muted/30 border-border font-mono text-sm h-10">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="typescript">TypeScript</SelectItem>
                    <SelectItem value="javascript">JavaScript</SelectItem>
                    <SelectItem value="python">Python</SelectItem>
                    <SelectItem value="rust">Rust</SelectItem>
                    <SelectItem value="go">Go</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label className="font-mono text-[11px] uppercase tracking-wider text-muted-foreground">Framework</Label>
                <Select value={form.framework} onValueChange={(v) => setForm({ ...form, framework: v })}>
                  <SelectTrigger className="bg-muted/30 border-border font-mono text-sm h-10">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="react">React</SelectItem>
                    <SelectItem value="nextjs">Next.js</SelectItem>
                    <SelectItem value="express">Express</SelectItem>
                    <SelectItem value="fastapi">FastAPI</SelectItem>
                    <SelectItem value="none">None</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="glass rounded-xl p-5">
            <Label className="font-mono text-[11px] uppercase tracking-wider text-muted-foreground mb-2 block">Prompt</Label>
            <Textarea
              value={form.prompt}
              onChange={(e) => setForm({ ...form, prompt: e.target.value })}
              placeholder="Describe the application you want to generate in detail..."
              required
              rows={10}
              className="bg-muted/30 border-border font-mono text-sm resize-none"
            />
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }}>
            <Button type="submit" disabled={loading} className="w-full h-11 font-mono text-sm bg-primary hover:bg-primary/90 glow-primary">
              {loading ? (
                <Loader2 className="w-4 h-4 animate-spin mr-2" />
              ) : (
                <Sparkles className="w-4 h-4 mr-2" />
              )}
              {loading ? "Forging..." : "Forge Project"}
            </Button>
          </motion.div>
        </form>
      </div>
    </AppLayout>
  );
}
