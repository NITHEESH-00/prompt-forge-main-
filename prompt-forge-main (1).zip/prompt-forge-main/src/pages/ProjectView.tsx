import { useEffect, useState, useCallback } from "react";
import { useParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { AppLayout } from "@/components/AppLayout";
import { LivePreview, LogEntry } from "@/components/LivePreview";
import { ExecutionLogs } from "@/components/ExecutionLogs";
import { BuildProgress } from "@/components/BuildProgress";
import { StatusOverlay } from "@/components/StatusOverlay";
import { ResizablePanelGroup, ResizablePanel, ResizableHandle } from "@/components/ui/resizable";
import { motion, AnimatePresence } from "framer-motion";
import { Loader2, FileCode, CheckCircle2, AlertCircle, Clock, ChevronRight } from "lucide-react";
import Editor from "@monaco-editor/react";
import type { Json } from "@/integrations/supabase/types";

interface ProjectFile {
  path: string;
  content: string;
  language: string;
}

interface Project {
  id: string;
  title: string;
  description: string | null;
  status: string;
  files: Json;
  language: string | null;
  framework: string | null;
  error_message: string | null;
  created_at: string;
}

function getMonacoLanguage(lang: string): string {
  const map: Record<string, string> = {
    ts: "typescript", tsx: "typescript", js: "javascript", jsx: "javascript",
    py: "python", rs: "rust", go: "go", json: "json", md: "markdown",
    css: "css", html: "html", yaml: "yaml", yml: "yaml",
  };
  return map[lang] || "plaintext";
}

function getFileIcon(path: string): string {
  const ext = path.split('.').pop() || '';
  const icons: Record<string, string> = {
    tsx: "⚛", jsx: "⚛", ts: "TS", js: "JS", css: "🎨", html: "◇", json: "{ }", md: "📝",
  };
  return icons[ext] || "📄";
}

export default function ProjectView() {
  const { id } = useParams<{ id: string }>();
  const [project, setProject] = useState<Project | null>(null);
  const [selectedFile, setSelectedFile] = useState<ProjectFile | null>(null);
  const [loading, setLoading] = useState(true);
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [logsVisible, setLogsVisible] = useState(false);
  const [fileTreeCollapsed, setFileTreeCollapsed] = useState(false);

  const handleLog = useCallback((entry: LogEntry) => {
    setLogs(prev => [...prev.slice(-200), entry]);
  }, []);

  useEffect(() => {
    if (!id) return;

    const fetchProject = async () => {
      const { data } = await supabase.from("projects").select("*").eq("id", id).single();
      if (data) {
        setProject(data as Project);
        const files = (data.files ?? []) as unknown as ProjectFile[];
        if (files.length > 0) setSelectedFile(files[0]);
      }
      setLoading(false);
    };

    fetchProject();

    const interval = setInterval(async () => {
      const { data } = await supabase.from("projects").select("status, files, error_message").eq("id", id).single();
      if (data) {
        setProject((prev) => prev ? { ...prev, ...data } as Project : null);
        if (data.status === "DONE" || data.status === "FAILED") {
          clearInterval(interval);
          if (data.status === "DONE") {
            const files = (data.files ?? []) as unknown as ProjectFile[];
            if (files.length > 0 && !selectedFile) setSelectedFile(files[0]);
          }
        }
      }
    }, 3000);

    return () => clearInterval(interval);
  }, [id]);

  if (loading) {
    return (
      <AppLayout>
        <div className="flex items-center justify-center h-full">
          <Loader2 className="w-5 h-5 animate-spin text-primary" />
        </div>
      </AppLayout>
    );
  }

  if (!project) {
    return (
      <AppLayout>
        <div className="flex items-center justify-center h-full">
          <p className="text-sm text-muted-foreground font-mono">Project not found</p>
        </div>
      </AppLayout>
    );
  }

  const files = (project.files ?? []) as unknown as ProjectFile[];
  const isProcessing = project.status === "PROCESSING" || project.status === "PENDING";
  const isFailed = project.status === "FAILED";
  const isDone = project.status === "DONE";

  return (
    <AppLayout>
      <div className="flex flex-col h-[calc(100vh-2.75rem)] relative">
        {/* Project header bar */}
        <div className="h-10 flex items-center justify-between px-3 border-b border-border glass-strong shrink-0 z-10">
          <div className="flex items-center gap-2.5">
            <FileCode className="w-4 h-4 text-primary" />
            <span className="font-mono text-xs font-semibold text-foreground">{project.title}</span>
            {project.framework && (
              <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-secondary text-secondary-foreground">
                {project.framework}
              </span>
            )}
          </div>
          <div className="flex items-center gap-2">
            {isProcessing && <Loader2 className="w-3.5 h-3.5 text-forge-cyan animate-spin" />}
            {isDone && <CheckCircle2 className="w-3.5 h-3.5 text-forge-green" />}
            {isFailed && <AlertCircle className="w-3.5 h-3.5 text-forge-red" />}
            <span className="text-[10px] font-mono text-muted-foreground">{project.status}</span>
          </div>
        </div>

        {/* Build progress */}
        <AnimatePresence>
          {isProcessing && (
            <BuildProgress completed={0} total={1} label="Generating code with AI..." />
          )}
        </AnimatePresence>

        {/* Status overlays */}
        <AnimatePresence>
          {isProcessing && (
            <StatusOverlay status="architecting" message="AI is generating your project files..." />
          )}
          {isFailed && (
            <StatusOverlay status="failed" message={project.error_message || "Generation failed"} />
          )}
        </AnimatePresence>

        {/* Main IDE area */}
        {isDone && files.length > 0 ? (
          <div className="flex-1 min-h-0 flex flex-col">
            <ResizablePanelGroup direction="horizontal" className="flex-1 min-h-0">
              {/* File tree + Editor panel */}
              <ResizablePanel defaultSize={50} minSize={30}>
                <div className="flex h-full">
                  {/* File tree */}
                  <div className={`border-r border-border bg-card/30 overflow-auto shrink-0 transition-all ${fileTreeCollapsed ? 'w-0 opacity-0' : 'w-48'}`}>
                    <div className="p-2">
                      <p className="text-[10px] font-mono uppercase tracking-wider text-muted-foreground/50 px-2 py-1.5 mb-1">
                        Explorer
                      </p>
                      {files.map((f) => (
                        <button
                          key={f.path}
                          onClick={() => setSelectedFile(f)}
                          className={`w-full text-left px-2 py-1.5 rounded text-[11px] font-mono flex items-center gap-1.5 transition-colors ${
                            selectedFile?.path === f.path
                              ? "bg-primary/10 text-primary"
                              : "text-muted-foreground hover:text-foreground hover:bg-muted/30"
                          }`}
                        >
                          <span className="text-[10px] w-4 text-center shrink-0">{getFileIcon(f.path)}</span>
                          <span className="truncate">{f.path}</span>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Editor */}
                  <div className="flex-1 min-w-0 flex flex-col">
                    {/* Editor tab bar */}
                    {selectedFile && (
                      <div className="h-8 flex items-center px-2 border-b border-border glass-strong shrink-0">
                        <button
                          onClick={() => setFileTreeCollapsed(!fileTreeCollapsed)}
                          className="p-1 rounded text-muted-foreground hover:text-foreground hover:bg-muted/30 transition-colors mr-1"
                        >
                          <ChevronRight className={`w-3 h-3 transition-transform ${fileTreeCollapsed ? '' : 'rotate-180'}`} />
                        </button>
                        <span className="text-[10px] font-mono text-muted-foreground">{getFileIcon(selectedFile.path)}</span>
                        <span className="text-[11px] font-mono text-foreground/80 ml-1.5">{selectedFile.path}</span>
                      </div>
                    )}
                    <div className="flex-1 min-h-0">
                      {selectedFile && (
                        <Editor
                          height="100%"
                          theme="vs-dark"
                          language={getMonacoLanguage(selectedFile.path.split(".").pop() || "")}
                          value={selectedFile.content}
                          options={{
                            readOnly: true,
                            minimap: { enabled: false },
                            fontSize: 12,
                            fontFamily: "'JetBrains Mono', monospace",
                            lineNumbers: "on",
                            scrollBeyondLastLine: false,
                            padding: { top: 8 },
                            renderLineHighlight: "gutter",
                            guides: { indentation: true, bracketPairs: true },
                            bracketPairColorization: { enabled: true },
                          }}
                        />
                      )}
                    </div>
                  </div>
                </div>
              </ResizablePanel>

              <ResizableHandle withHandle />

              {/* Preview panel */}
              <ResizablePanel defaultSize={50} minSize={25}>
                <div className="h-full flex flex-col">
                  <div className="flex-1 min-h-0">
                    <LivePreview files={files} onLog={handleLog} />
                  </div>
                  <ExecutionLogs
                    logs={logs}
                    visible={logsVisible}
                    onToggle={() => setLogsVisible(!logsVisible)}
                    onClear={() => setLogs([])}
                  />
                </div>
              </ResizablePanel>
            </ResizablePanelGroup>
          </div>
        ) : isDone && files.length === 0 ? (
          <div className="flex-1 flex items-center justify-center">
            <p className="text-sm text-muted-foreground font-mono">No files generated</p>
          </div>
        ) : null}
      </div>
    </AppLayout>
  );
}
