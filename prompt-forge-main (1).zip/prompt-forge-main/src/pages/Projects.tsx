import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { AppLayout } from "@/components/AppLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { motion } from "framer-motion";
import { FolderOpen, Plus, Search, Clock, CheckCircle2, AlertCircle, Loader2, Trash2 } from "lucide-react";
import { toast } from "sonner";

interface ProjectRow {
  id: string;
  title: string;
  description: string | null;
  status: string;
  framework: string | null;
  language: string | null;
  tags: string[];
  created_at: string;
}

const statusConfig: Record<string, { icon: any; color: string }> = {
  PENDING: { icon: Clock, color: "text-forge-amber" },
  PROCESSING: { icon: Loader2, color: "text-forge-cyan" },
  DONE: { icon: CheckCircle2, color: "text-forge-green" },
  FAILED: { icon: AlertCircle, color: "text-forge-red" },
};

export default function Projects() {
  const { user } = useAuth();
  const [projects, setProjects] = useState<ProjectRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");

  useEffect(() => {
    if (!user) return;
    supabase
      .from("projects")
      .select("id, title, description, status, framework, language, tags, created_at")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false })
      .then(({ data }) => {
        setProjects(data ?? []);
        setLoading(false);
      });
  }, [user]);

  const handleDelete = async (id: string) => {
    const { error } = await supabase.from("projects").delete().eq("id", id);
    if (error) {
      toast.error("Failed to delete project");
    } else {
      setProjects(projects.filter((p) => p.id !== id));
      toast.success("Project deleted");
    }
  };

  const filtered = projects.filter(
    (p) =>
      p.title.toLowerCase().includes(search.toLowerCase()) ||
      p.framework?.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <AppLayout>
      <div className="p-6 max-w-4xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-xl font-bold font-mono text-foreground">My Projects</h1>
          <Link to="/new-project">
            <Button size="sm" className="font-mono text-xs bg-primary hover:bg-primary/90 h-8">
              <Plus className="w-3.5 h-3.5 mr-1" /> New
            </Button>
          </Link>
        </div>

        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search projects..."
            className="pl-10 bg-muted/30 border-border font-mono text-sm h-10"
          />
        </div>

        {loading ? (
          <div className="flex items-center gap-2 text-muted-foreground font-mono text-sm py-12 justify-center">
            <Loader2 className="w-4 h-4 animate-spin" /> Loading...
          </div>
        ) : filtered.length === 0 ? (
          <div className="glass rounded-xl p-12 text-center text-muted-foreground font-mono text-sm">
            {search ? "No matching projects" : "No projects yet"}
          </div>
        ) : (
          <div className="grid gap-2">
            {filtered.map((p, i) => {
              const sc = statusConfig[p.status] || statusConfig.PENDING;
              const Icon = sc.icon;
              return (
                <motion.div
                  key={p.id}
                  initial={{ opacity: 0, y: 5 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.03 }}
                  className="glass rounded-lg px-4 py-3 hover:glow-border transition-all group"
                >
                  <div className="flex items-start justify-between gap-4">
                    <Link to={`/project/${p.id}`} className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <FolderOpen className="w-4 h-4 text-muted-foreground group-hover:text-primary transition-colors shrink-0" />
                        <span className="font-mono text-sm font-medium text-foreground truncate">{p.title}</span>
                      </div>
                      {p.description && (
                        <p className="text-xs text-muted-foreground font-mono ml-6 truncate">{p.description}</p>
                      )}
                      <div className="flex items-center gap-2 mt-2 ml-6">
                        {p.framework && (
                          <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-secondary text-secondary-foreground">
                            {p.framework}
                          </span>
                        )}
                        <Icon className={`w-3 h-3 ${sc.color} ${p.status === "PROCESSING" ? "animate-spin" : ""}`} />
                        <span className="text-[10px] text-muted-foreground font-mono">
                          {new Date(p.created_at).toLocaleDateString()}
                        </span>
                      </div>
                    </Link>
                    <button
                      onClick={() => handleDelete(p.id)}
                      className="text-muted-foreground hover:text-destructive transition-colors opacity-0 group-hover:opacity-100 p-1 rounded hover:bg-destructive/10"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </motion.div>
              );
            })}
          </div>
        )}
      </div>
    </AppLayout>
  );
}
